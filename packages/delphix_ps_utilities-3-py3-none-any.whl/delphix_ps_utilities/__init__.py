def merge_dictionaries(base_dictionary, dictionary_to_override_with):
    """
    Merges two dictionaries including nested dictionaries.
    If there are overlapping keys, values from d2 take precedence.

    Args:
        base_dictionary (dict): The first dictionary.
        dictionary_to_override_with (dict): The second dictionary.

    Returns:
        dict: The merged dictionary.

    """
    merged = base_dictionary.copy()
    for k, v in dictionary_to_override_with.items():
        if (
            k in merged
            and isinstance(merged[k], dict)
            and isinstance(v, dict)
        ):
            merged[k] = merge_dictionaries(merged[k], v)
        else:
            merged[k] = v

    return merged
