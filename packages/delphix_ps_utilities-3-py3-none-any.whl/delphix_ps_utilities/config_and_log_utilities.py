import datetime as dt
import sys
from pathlib import Path
import yaml
import traceback
import json
import os
import re
import uuid

from delphix_ps_utilities import merge_dictionaries
from delphix_ps_utilities.log_manager.log_config import LogConfig
from delphix_ps_utilities.encryption_manager import EncryptionManager
from delphix_ps_utilities.db_manager.oracle_modules import validate_oracle_connection_config
from delphix_ps_utilities.db_manager.postgresql_modules import validate_postgres_connection_config
from delphix_ps_utilities.db_manager.sqlite_modules import validate_sqlite_connection_config


class ConfigAndLogUtilities(EncryptionManager):
    """
    This class handles configuration parsing and validation, logging setup, directory creations and
    encryption/decryption of credentials.

    Attributes:
        _config_dict (dict): A dictionary to hold configuration parameters

    """


    def __init__(self, config_dict=None):
        """
        Initialize the ConfigAndLogUtilities class.

        """
        self._config_dict = config_dict if config_dict else {}
        if self._config_dict.get('raw_session_ts', None) is None:
            self._config_dict['raw_session_ts'] = dt.datetime.now(dt.timezone.utc)
        if self._config_dict.get('debug_mode', None) is None:
            self._config_dict['debug_mode'] = False

    def print_sample_config(self):
        """
        Prints a sample configuration in YAML format to the console.

        """

        sample_config = {
            'log_directory': 'Path for logs',
            'log_style': 'classic',
            'data_directory': 'Path for data directory',
            'sample_oracle_connection_details': {
                'host': 'host name or IP',
                'port': 1521,
                'use_sid': True,
                'sid_or_service_name': 'SID or Service',
                'username': 'Encrypted Username',
                'password': 'Encrypted Password'},
            'base_key': '1YqK}-uWYinB]!=uh@pn',
            'secondary_key': 'q;I[k#;#e[?8N=l%|v7D',
            'repository_config': {
                'platform': 'sqlite',
                'sqlite_details': {
                    'db_name': 'inventory.db',
                    'database_directory': 'Path to sqlite db'}},
            'masking_engine': {'name': 'engine1',
                 'url': 'Engine URL',
                 'login': 'Encrypted User',
                 'password': 'Encrypted Password',
                 'ssl_certs': False
                 },
            'hyperscale_orchestrator': {
                'api_key': 'API Key',
                'url': 'Hyperscale URL',
                'connector': 'Type of Hyperscale connector'
            }
            }


        print("# Sample Configuration")
        print(yaml.dump(sample_config, sort_keys=False, indent=4))

    def update_session_config(self, new_config):
        """
        Merges new configuration parameters into the existing configuration dictionary.

        Args:
            new_config (dict): New configuration dictionary

        Modifies:
            self._config_dict (dict): Merged configuration dictionary

        """

        self._config_dict = merge_dictionaries(self._config_dict, new_config)

    def get_session_config(self):
        """
        Returns the current configuration dictionary.

        Returns:
            dict: Current configuration dictionary

        """

        return self._config_dict

    def check_and_create_directory(self, directory):
        """
        Creates a directory if it doesn't exist.

        Args:
            directory (Path): The path of the directory to check/create.

        Returns:
            bool: True if the directory exists or was created successfully, False otherwise.

        """

        try:
            print(f"Checking existence of directory {directory} and creating if necessary")
            Path(directory).mkdir(mode=0o755, parents=True, exist_ok=True)
            return True
        except Exception as e:
            self.exit_on_error(msg=f"Failed creating directory {directory}, with error {e}")
            return False

    def read_config(self, env_vars=None, fail_on_missing_mandatory=True):
        """
        Reads the config based on specified config type.
        Expects config_dict to have a key 'config_type' which can be one of the below:
            'yaml' - Reads config from a YAML file specified in 'config_file' key of config_dict
            'json' - Reads config from a JSON file specified in 'config_file' key of config_dict
            'env' - Reads config from environment variables (Not yet implemented)
            'azure_secrets' - Reads config from Azure Key Vault (Not yet implemented)
            'gcp_secrets' - Reads config from GCP Secret Manager (Not yet implemented)

        Args:
            env_vars (list, optional): A list fo dictionaries specifying environment variables to read config from. Eg.
                                        [
                                            {
                                            'env_variable': 'VARIABLE_NAME',
                                            'key_name_in_config': 'key_name_in_returned_config_dict',
                                            'mandatory': True|False,
                                            'cast_type': str|int|bool|float (default is str)
                                            'default_value': 'default_value_if_not_mandatory',
                                            'parent_hierarchy': 'Comma separated list of parent keys if any'
                                            }
                                        ]

                                        The value of env_variable defines the environment variable to read the config
                                        value from.
                                        The value of key_name_in_config defines the key name to use in the
                                        internal config dictionary.
                                        parent_hierarchy is optional and if specified, defines the hierarchy of
                                        config as stored in the config dictionary. The 1st value is the top level key.
            fail_on_missing_mandatory (bool): Whether to raise an error if any mandatory environment variable is missing. Defaults to True.

        Returns:
            dict: Parsed dictionary as read from the configuration source

        Raises:
            SystemExit: If the configuration can't be read
        """

        valid_config_types = ['yaml', 'json', 'env', 'azure_secrets', 'gcp_secrets']
        config_type = self._config_dict.get('config_type', 'yaml').lower()

        if config_type not in valid_config_types:
            self.exit_on_error(msg=f'Invalid config_type {config_type}, valid types are {valid_config_types}')
            return None
        elif config_type == 'yaml':
            return self.read_config_from_yaml()
        elif config_type == 'json':
            return self.read_config_from_json()
        elif config_type == 'env':
            return self.read_config_from_environment_variables(env_vars=env_vars,
                                                                fail_on_missing_mandatory=fail_on_missing_mandatory)
        elif config_type == 'azure_secrets':
            self.exit_on_error(msg='Reading config from azure secrets is not yet available')
            return None
        elif config_type == 'gcp_secrets':
            self.exit_on_error(msg='Reading config from gcp secrets is not yet available')
            return None
        else:
            self.exit_on_error(msg=f'Invalid config_type {config_type}')
            return None

    def read_config_from_yaml(self):
        """
        Reads configuration from a YAML file specified in the config_dict.

        Returns:
            dict: Parsed configuration dictionary as read from the YAML file.

        Raises:
            SystemExit: If the configuration file can't be read or parsed.

        """

        config_file = self._config_dict.get('config_file')
        if not config_file:
            self.exit_on_error(msg='No config_file specified in config_dict')

        try:
            print(f"Reading config from : {config_file}")
            with open(config_file, encoding="utf-8") as f:
                application_config = yaml.safe_load(f)
        except Exception as e:
            self.exit_on_error(msg=f"Error occurred in reading config", exc=e)

        if not application_config:
            self.exit_on_error(msg='YAML file is empty or malformed')

        return application_config

    def read_config_from_json(self):
        """
        Reads configuration from a JSON file specified in the config_dict.

        Returns:
            dict: Parsed configuration dictionary as read from the JSON file.

        Raises:
            SystemExit: If the configuration file can't be read or parsed.

        """

        config_file = self._config_dict.get('config_file')
        if not config_file:
            self.exit_on_error(msg='No config_file specified in config_dict')

        try:
            print(f"Reading config from : {config_file}")
            with open(config_file, encoding="utf-8") as f:
                application_config = json.loads(f.read())
        except Exception as e:
            self.exit_on_error(msg=f"Error occurred in reading config", exc=e)

        if not application_config:
            self.exit_on_error(msg='JSON file is empty or malformed')

        return application_config

    def read_config_from_environment_variables(self, env_vars, fail_on_missing_mandatory=True):
        """
        Reads configuration from environment variables.

        Args:
            env_vars (list): A list of dictionaries specifying environment variables to read config from.
                             See read_config method for details. Check the docstring of read_config method for details.

        Returns:
            dict: Parsed configuration dictionary as read from environment variables.

        Raises:
            SystemExit: If any mandatory environment variable is missing.
        """

        missing_env_vars = []
        casting_errors = []
        application_config = {}

        for each_env_var in env_vars:
            env_var_value = os.getenv(each_env_var.get('env_variable'))
            key_value = each_env_var.get('key_name_in_config')
            if key_value is None:
                missing_env_vars.append(each_env_var.get('env_variable'))
                continue
            if each_env_var.get('mandatory', False):
                if not env_var_value:
                    missing_env_vars.append(each_env_var.get('env_variable'))
                    continue
            else:
                if env_var_value is None:
                    env_var_value = each_env_var.get('default_value', None)

            cast_type = each_env_var.get('cast_type', 'str')

            try:
                if cast_type.lower() == 'str':
                    env_var_value = str(env_var_value) if env_var_value is not None else None
                elif cast_type.lower() == 'int':
                    env_var_value = int(env_var_value) if env_var_value is not None else None
                elif cast_type.lower() == 'float':
                    env_var_value = float(env_var_value) if env_var_value is not None else None
                elif cast_type.lower() == 'bool':
                    env_var_value = str(env_var_value).lower() in ['true', '1', 't', 'y', 'yes', 'on']
                else:
                    env_var_value = env_var_value
            except Exception as e:
                casting_errors.append(each_env_var.get('env_variable'))
                print(e)


            if each_env_var.get('parent_hierarchy', None):
                parent_hierarchy = each_env_var.get('parent_hierarchy')
                if not isinstance(parent_hierarchy, list):
                    application_config[key_value] = env_var_value
                    continue
                current_level = application_config
                for each_level in parent_hierarchy:
                    if not isinstance(each_level, str):
                        self.exit_on_error(msg=f"Invalid parent_hierarchy for : {each_env_var.get('env_variable')}, "
                                               f"{each_level} must be a string")
                    if each_level not in current_level:
                        current_level[each_level] = {}
                    elif not isinstance(current_level[each_level], dict):
                        self.exit_on_error(msg=f"Invalid parent_hierarchy for : {each_env_var.get('env_variable')}, "
                                               f"{each_level} must be a dictionary in the configuration")
                    current_level = current_level[each_level]
                current_level[key_value] = env_var_value
            else:
                application_config[key_value] = env_var_value

        if missing_env_vars and casting_errors and fail_on_missing_mandatory:
            self.exit_on_error(msg=f'Mandatory environment variables missing: {missing_env_vars}, '
                                   f'Error in casting environment variables to specified type: {casting_errors}')
        elif missing_env_vars and fail_on_missing_mandatory:
            self.exit_on_error(msg=f'Mandatory environment variables missing: {missing_env_vars}')

        elif casting_errors:
            self.exit_on_error(msg=f'Error in casting environment variables to specified type: {casting_errors}')

        return application_config

    def check_configuration_completeness(self, application_config:dict, env_vars:list):
        """
        Checks if all the mandatory keys listed in env_vars are present in the application_config dictionary.
        Args:
            application_config (dict): The application configuration dictionary to check.
            env_vars (list): A list of dictionaries specifying mandatory keys to check in the application_config.
                             Each dictionary should have the following structure:
                             {
                                "env_variable": "VARIABLE_NAME",
                                "key_name_in_config": "key_name_in_returned_config_dict",
                                "mandatory": [true|false],
                                "cast_type": "str|int|bool|float",
                                "parent_hierarchy": [
                                    "Comma separated list of parent keys if any, with the leftmost key being the 
                                    top level key in the config dictionary"
                                ]
                            }
    """

        if not isinstance(application_config, dict):
            self.exit_on_error(msg='application_config must be a dictionary')

        if not isinstance(env_vars, list):
            self.exit_on_error(msg='env_vars must be a list of dictionaries')

        missing_required_keys = []

        for each_env_var in env_vars:
            if not isinstance(each_env_var, dict):
                continue

            key_name = each_env_var.get('key_name_in_config')
            env_var_name = each_env_var.get('env_variable', key_name)
            is_mandatory = each_env_var.get('mandatory', False)

            if not key_name:
                if is_mandatory:
                    missing_required_keys.append(str(env_var_name))
                continue

            key_exists = self._check_key_in_hierarchy(
                application_config=application_config,
                key_name=key_name,
                parent_hierarchy=each_env_var.get('parent_hierarchy', None)
            )

            if is_mandatory and not key_exists:
                missing_required_keys.append(str(env_var_name))

        if missing_required_keys:
            self.exit_on_error(
                msg=f'Mandatory configuration keys are missing from application config: {missing_required_keys}'
            )

        return True

    @staticmethod
    def _check_key_in_hierarchy(application_config:dict, key_name:str, parent_hierarchy=None):
        """
        Checks if key_name exists in application_config at the level specified by parent_hierarchy.

        Args:
            application_config (dict): The config dictionary to inspect.
            key_name (str): The key to check for.
            parent_hierarchy (list|None): Optional list representing nested parent keys.

        Returns:
            bool: True if key exists at target location, False otherwise.
        """

        if not isinstance(application_config, dict) or not isinstance(key_name, str) or not key_name:
            return False

        current_level = application_config

        if parent_hierarchy:
            if not isinstance(parent_hierarchy, list):
                return key_name in application_config

            for each_parent in parent_hierarchy:
                if not isinstance(each_parent, str):
                    return False
                if not isinstance(current_level, dict) or each_parent not in current_level:
                    return False
                current_level = current_level[each_parent]

        if not isinstance(current_level, dict):
            return False

        return key_name in current_level

    def validate_logging_configuration(self, application_config):
        """
        Validates the logging configuration in the application configuration.

        Args:
            application_config (dict): The application configuration dictionary.

        Returns:
            bool: True if the logging configuration is valid, False otherwise.
        """

        log_mode = application_config.get('log_mode', 'console')
        self._config_dict['log_mode'] = log_mode
        self._config_dict['log_format_specification'] = application_config.get('log_format_specification', None)
        self._config_dict['log_setup'] = dict()
        valid_log_modes = ['file', 'console', 'azure_insights', 'gcp_logging']

        if log_mode not in valid_log_modes:
            self.exit_on_error(msg=f'Invalid log_type {log_mode}, valid types are {valid_log_modes}')
            return False
        elif log_mode == 'file':
            return self.validate_filesystem_logging_configuration(application_config)
        elif log_mode == 'console':
            return True
        elif log_mode == 'azure_insights':
            self.exit_on_error(msg='Azure Insights logging configuration is not yet supported')
            return False
        elif log_mode == 'gcp_logging':
            self.exit_on_error(msg='GCP logging configuration is not yet supported')
            return False
        else:
            return False

    def validate_filesystem_logging_configuration(self, application_config):
        """
        Validates the filesystem logging configuration in the application configuration.

        Args:
            application_config (dict): The application configuration dictionary.

        Returns:
            bool: True if the filesystem logging configuration is valid, False otherwise.
        """

        log_directory = application_config.get('log_directory')
        if not log_directory:
            self.exit_on_error(msg='log_type is specified as "file" but no log_directory specified in config_dict')
            return False

        if not self.check_and_create_directory(log_directory):
            self.exit_on_error(msg=f'Failed to create log_directory {log_directory}')
            return False

        self._config_dict['log_directory'] = log_directory
        if application_config.get('log_file_name', None) is not None:
            log_file_name = application_config.get('log_file_name')
        else:
            log_file_name = 'app.log'

        self._config_dict['log_file'] = os.path.join(self._config_dict['log_directory'], log_file_name)
        self._config_dict['log_setup']['log_file'] = self._config_dict['log_file']
        return True

    def set_database_connection_properties(self, application_config):
        """

        Sets database connection properties in the global session configuration.

        Args:
            application_config (dict): The application configuration dictionary.

        """

        db_properties = application_config.get('db_connection_properties', {})
        self._config_dict['db_connection_properties'] = db_properties

    def validate_keys(self, application_config):
        """
        Validates and populates encryption/decryption keys in the global configuration dictionary

        Args:
            application_config (dict): The dictionary of config read from configuration YAML file

        Raises:
            SystemExit: If any required repository configuration is missing or invalid.
        """

        base_key = application_config.get('base_key')
        if not base_key:
            self.exit_on_error(msg='Base key (base_key) is not defined in the config')

        self._config_dict['base_key'] = base_key

        secondary_key = application_config.get('secondary_key')
        if not secondary_key:
            self.exit_on_error(msg='Secondary key or salt (secondary_key) is not defined in the config')

        self._config_dict['salt'] = secondary_key

    def validate_directory(self, application_config, directory_identifier: str):
        """
        Validates and populates a given directory in the global configuration dictionary

        Args:
            application_config (dict): The dictionary of config read from configuration source
            directory_identifier (str): The identifier which specifies the key in the config dict for the directory

        Raises:
            SystemExit: If any required repository configuration is missing or invalid.

        Returns:
            bool: True if the directory is valid and exists or was created, False otherwise.
        """

        directory = application_config.get(directory_identifier)

        if not directory:
            self.exit_on_error(msg=f"Directory: {directory_identifier} is not defined in the config")
            return False
        else:
            directory = Path(directory.strip())
            if not self.check_and_create_directory(directory):
                return False
            self._config_dict[directory_identifier] = directory
            return True

    def validate_masking_engine_config(self, application_config):
        """
        Validates and populates masking engines in the global configuration dictionary
        Expects a dictionary named as 'masking_engine' in the application_config with below keys:
            name (str): Name of the masking engine. If not defined, a random name is generated.
            url (str): The base URL of the masking engine.
            login (str): The login ID for the masking engine.
            password (str): The password for the masking engine.
            ssl_certs (str|bool): Path to SSL certificates file or False to disable SSL verification.
            profiling_config (dict): Optional dictionary with profiling configuration overrides.

        Args:
            application_config (dict): The dictionary of config read from configuration source

        Modifies:
            application_config (dict): Populates/overrides certain keys in the masking_engine dictionary
            self._config_dict (dict): Initializes the validated masking_engine configuration

        Raises:
            SystemExit: If any required repository configuration is missing or invalid.

        """

        masking_engine = application_config.get('masking_engine')
        self._config_dict['masking_engine'] = dict()
        if not masking_engine:
            self.exit_on_error(msg='Masking engine config is missing')

        if not isinstance(masking_engine, dict):
            self.exit_on_error(msg='Expecting a dictionary/json of masking engine in the config')

        name = masking_engine.get('name')
        url = masking_engine.get('url')
        login = masking_engine.get('login')
        password = masking_engine.get('password')
        ssl_certs = masking_engine.get('ssl_certs')
        profiling_config = masking_engine.get('profiling_config', {})

        if not name:
            name = str(uuid.uuid4())

        application_config['masking_engine']['name'] = name

        if not url:
            self.exit_on_error(msg='URL is missing in masking engine configuration')

        base_url = re.match(r"(https?://[^/]+)", url.strip())
        if not base_url:
            self.exit_on_error(msg='Invalid URL specified in masking engine configuration, should be of the form '
                                   'http(s)://<host>[:port]')

        application_config['masking_engine']['url'] = f'{base_url.group(1)}/masking/api'

        if not ssl_certs:
            verify_ssl = False
        else:
            if Path(ssl_certs.strip()).exists():
                verify_ssl = ssl_certs.strip()
            else:
                verify_ssl = False
                self.exit_on_error(msg='Supplied ssl_certs in the config not found')

        application_config['masking_engine']['verify_ssl'] = verify_ssl

        if not login:
            self.exit_on_error(msg='Login ID is missing in masking engine configuration')

        if not password:
            self.exit_on_error(msg='Password is missing in masking engine configuration')

        application_config['masking_engine']['login'] = login
        application_config['masking_engine']['password'] = password

        application_config['masking_engine']['profiling_config'] = profiling_config

    def validate_repository_config(self, application_config):
        """
        Validates and populates repository-specific configurations based on the selected platform
        (SQLite, Oracle, or Postgres).

        Args:
            application_config (dict): The dictionary of config read from configuration source

        Raises:
            SystemExit: If any required repository configuration is missing or invalid.
        """

        repository_config = application_config.get('repository_config')
        if not repository_config:
            self.exit_on_error(msg="Repository Config is not defined in the config")

        platform = repository_config.get('platform')
        if not platform:
            self.exit_on_error(msg='Platform not defined in repository config')

        conn_details = repository_config.get(platform.lower(), {})
        if not conn_details:
            self.exit_on_error(
                msg=f'Repository platform is specified as {platform}, '
                    f'but the key for {platform.lower()} is missing in config'
            )

        if platform.lower() == 'sqlite':
            self.validate_sqlite_connection_config(conn_details, 'repository')
        elif platform.lower() == 'oracle':
            self.validate_oracle_connection_config(
                conn_details,
                'repository'
            )

        elif platform.lower() == 'postgres':
            self.validate_postgres_connection_config(
                conn_details,
                'repository'
            )

        else:
            self.exit_on_error(
                msg=f'Unsupported repository platform defined in config. Only sqlite, oracle and postgres '
                  f'are supported'
            )

    def validate_sqlite_connection_config(self, sqlite_details, purpose='sqlite'):
        """
        Validates and populates sqlite specific connection configurations

        Args:
            sqlite_details (dict): The dictionary of sqlite connection details read from configuration source.
                                   The dictionary is expected to have below keys:
                                    db_name (str): The name of the sqlite database.
                                    db_directory (str): The directory where the sqlite database is or will be located.
            purpose (str): The purpose of the sqlite connection details.
        Raises:
            SystemExit: If any required sqlite configuration is missing or invalid.

        Returns:
            None. The method modifies the input sqlite_details dictionary in-place

        """

        validate_sqlite_connection_config(sqlite_details, self.exit_on_error, self.check_and_create_directory, purpose)

    def validate_oracle_connection_config(self, oracle_details, purpose='Oracle'):
        """
        Validates and populates oracle specific connection configurations

        Args:
            oracle_details (dict): The dictionary of oracle connection details read from configuration source
                                   The dictionary is expected to have below keys:
                                    host (str): The hostname or IP address of the Oracle database server.
                                    port (int): The port number on which the Oracle database server is listening.
                                    use_sid (bool): Whether to use SID or Service Name for connection.
                                    sid_or_service_name (str): The SID or Service Name of the Oracle database.
                                    username (str): The encrypted username for connecting to the Oracle database.
                                    password (str): The encrypted password for connecting to the Oracle database.
            purpose (str) : The purpose of validation, eg: Repository, Source, Target etc.

        Raises:
            SystemExit: If any required repository configuration is missing or invalid.

        Returns:
            None. It modifies the input oracle_details dictionary in-place

        """

        validate_oracle_connection_config(oracle_details, self.exit_on_error, purpose)

    def validate_postgres_connection_config(self, postgres_details, purpose='Postgres'):
        """
        Validates and populates postgres specific connection configurations

        Args:
            postgres_details (dict): The dictionary of PostgreSQL connection details read from configuration source
                                     The dictionary is expected to have some of the below keys:
                                        host (str): The hostname or IP address of the Oracle database server.
                                        port (int): The port number on which the Oracle database server is listening.
                                        database_name (str): Name of the database to connect to.
                                        dsn (str): The DSN to use for connection.
                                        is_dsn (bool): Whether to use DSN or individual parameters for connection.
                                        ssl_mode (str): SSL mode to use for the connection. Defaults to 'prefer' if not provided.
                                        username (str): The encrypted username for connecting to the Oracle database.
                                        password (str): The encrypted password for connecting to the Oracle database.

            purpose (str) : The purpose of validation, eg: Repository, Source, Target etc.

        Raises:
            SystemExit: If any required repository configuration is missing or invalid.

        Returns:
            None. It modifies the input oracle_details dictionary in-place

        """

        validate_postgres_connection_config(postgres_details, self.exit_on_error, purpose)

    def validate_hyperscale_orchestrator_config(self, application_config):
        """
        Validates and populates hyperscale orchestrator details in the global configuration dictionary

        Args:
            application_config (dict): The dictionary of config read from configuration YAML file

        Raises:
            SystemExit: If any required repository configuration is missing or invalid.

        """

        hyperscale_orchestrator = application_config.get('hyperscale_orchestrator', {})
        if not hyperscale_orchestrator:
            self.exit_on_error(msg='Hyperscale Orchestrator details are missing in config')

        max_parallel_api_calls_allowed = hyperscale_orchestrator.get('max_parallel_api_calls_allowed', 1)
        hyperscale_orchestrator['max_parallel_api_calls_allowed'] = max_parallel_api_calls_allowed

        ssl_certs = hyperscale_orchestrator.get('ssl_certs')
        if not ssl_certs:
            hyperscale_orchestrator['verify_ssl'] = False
        else:
            if Path(ssl_certs.strip()).exists():
                hyperscale_orchestrator['verify_ssl'] = ssl_certs.strip()
            else:
                self.exit_on_error(msg='Supplied ssl_certs in the config not found')

        for key in ['api_key', 'url', 'connector']:
            value = hyperscale_orchestrator.get(key)
            if not value:
                self.exit_on_error(msg=f'{key} is missing in hyperscale orchestrator config')

            if key == 'api_key':
                hyperscale_orchestrator['access_key'] = f'apk {value}'

        self._config_dict['hyperscale_orchestrator'] = hyperscale_orchestrator

    def create_logger(self, log_mode=None, log_setup=None):
        """
        Initializes and returns a logger object based on the provided configuration and handler type.

        Args:
            log_mode (str, optional): The logging mode, either 'file', 'console', 'azure_insights', or 'gcp_logging'.
                                      Defaults to None, in which case it uses the value from self._config_dict.
            log_setup (dict, optional): The logging setup parameters. Defaults to None, in which case it uses the value
                                        from self._config_dict.

        Returns:
            tuple: (LogConfig instance, logger object, log handler)

        Raises:
            SystemExit: If logger setup fails or required fields are missing.
        """

        log_mode = log_mode if log_mode else self._config_dict.get('log_mode')
        log_setup = log_setup if log_setup else self._config_dict.get('log_setup')

        log_object = LogConfig(self._config_dict.get('debug_mode'), log_mode,
                               self._config_dict.get('log_format_specification'), log_setup)

        app_logger, handler = log_object.setup_logging()
        if not app_logger or not handler:
            self.exit_on_error(msg=f'Failed to setup logging')
            return None, None, None

        return log_object, app_logger, handler

    def log_messages(self, message_queue=None):
        """
        Processes log messages from a queue and writes them to the configured log file.

        Args:
            message_queue (queue.Queue): The queue from which to read log messages.

        Returns:
            None

        """

        if not message_queue:
            self.exit_on_error(msg='No queue found in log_setup')
            return

        log_setup = {
            'log_file': self._config_dict['log_file'],
            'logger_name_prefix': 'funnel'
        }

        log_object, app_logger, handler = self.create_logger()

        if not app_logger or not handler:
            self.exit_on_error(msg=f'Failed to setup logging to read messages from queue')
            return

        while True:
            if message_queue.qsize() == 0:
                continue

            next_message = message_queue.get_nowait()
            if next_message == 'end':
                self.terminate_logging(log_object, handler, print_out=False)
                break

            app_logger.handle(next_message)

    @staticmethod
    def terminate_logging(log_object=None, handler=None, print_out: bool = True) -> None:
        """
        Gracefully terminates logging by closing the provided log handler.

        Args:
            log_object (LogConfig, optional): Log configuration object.
            handler (logging.Handler, optional): Logging handler to close.
            print_out (bool): Whether to print shutdown message. Defaults to True.

        Returns:
            None
        """

        if print_out:
            print('Shutting down')

        if handler:
            log_object.close_handler(handler)

    def exit_on_error(self, handler=None, log_object=None, msg=None, exc=None):
        """
        Terminates the application with exit code 1 and optionally closes log handlers.

        Args:
            handler (logging.Handler, optional): Log handler to close.
            log_object (LogConfig, optional): Log configuration object.
            msg (str, optional): Message to print
            exc (Exception, optional): The exception instance to show traceback for

        Returns:
            None

        Raises:
            SystemExit: Always exits the program with status code 1.
        """

        if msg:
            print(msg)

        if exc:
            print('\nTraceback:')
            traceback.print_exception(type(exc), exc, exc.__traceback__)

        if log_object:
            print('Operation failed, check logs')
            if handler:
                self.terminate_logging(log_object, handler)
            else:
                self.terminate_logging(log_object)
        else:
            print('Operation failed')
        sys.exit(1)