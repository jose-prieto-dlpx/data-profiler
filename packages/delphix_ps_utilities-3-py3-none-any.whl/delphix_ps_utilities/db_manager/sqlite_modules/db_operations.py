class SQLiteDbOperations:
    """
    Handles basic SQLite operations including SELECT, DML/DDL, and INSERT with ID return.

    Attributes:
        _properties (dict): Configuration properties for DB operations.
        _logger (logging.Logger): Logger instance for logging messages.

    """

    _properties = {
        'commit_size': 10000
    }

    def __init__(self, logger, properties=None):
        """
       Initializes the SQLiteDbOperations with configuration and logger.

       Args:
           properties (dict): Properties to use for sqlite db operations
           logger (logging.Logger): Logger instance for logging messages.
       """
        self._logger = logger
        self._properties = self._properties | (properties if properties else {})


    # Generic wrapper to execute select queries on sqlite DB
    def sqlite_select(self, db_conn, select_sql, query_data=(), desc_needed=False):
        """
        Executes a SELECT query on the database.

        Args:
            db_conn (sqlite3.Connection): Active SQLite database connection.
            select_sql (str): The SQL SELECT statement to execute.
            query_data (tuple, optional): Data to substitute in the query.
            desc_needed (bool, optional): Whether to return column names.

        Returns:
            tuple: (success, result) or (success, result, column_names)
        """

        db_cursor = db_conn.cursor()
        success = True
        try:
            self._logger.debug(f'Executing query : {select_sql}')
            if query_data:
                self._logger.debug(f'Sample query data is : ')
                self._logger.debug(query_data)
            query_result = db_cursor.execute(select_sql, query_data)
            data = query_result.fetchall()
        except Exception as e:
            success = False
            self._logger.exception(f"Query failed")
            self._logger.error(f"Query was : {select_sql}")
            db_cursor.close()
            if desc_needed:
                return success, None, None
            else:
                return success, None
        else:
            if desc_needed:
                col_names = [row[0] for row in query_result.description]
                db_cursor.close()
                return success, data, col_names
            else:
                db_cursor.close()
                return success, data

    # Generic DML or DDL wrapper for sqlite DB
    def sqlite_dml_or_ddl(self, db_conn, sql, query_data=None):
        """
        Executes a DML or DDL operation, with optional batching.

        Args:
            db_conn (sqlite3.Connection): Active SQLite database connection.
            sql (str): The SQL statement to execute.
            query_data (list, optional): List of tuples to use with executemany.

        Returns:
            bool: True if successful, False otherwise.
        """

        db_cursor = db_conn.cursor()
        commit_size = self._properties['commit_size']
        success = True
        self._logger.debug(f'Executing query : {sql}')
        if not query_data:
            try:
                db_cursor.execute(sql)
            except Exception as e:
                success = False
                self._logger.exception(f"Query failed")
                self._logger.error(f"Query was : {sql}")
            else:
                db_conn.commit()
        else:
            low_val = 0
            high_val = commit_size
            while True:
                batch_data = query_data[low_val:high_val]
                self._logger.debug(f'2 sample rows for dml : ')
                self._logger.debug(batch_data[:2])
                try:
                    db_cursor.executemany(sql, batch_data)
                except Exception as e:
                    success = False
                    self._logger.exception(f"Query failed because")
                    self._logger.error(f"Query was : {sql}")
                    self._logger.error(f"Failure row range : {low_val}, {high_val}")
                    break
                else:
                    db_conn.commit()

                    batch_data.clear()
                    if high_val >= len(query_data):
                        break

                    low_val = high_val
                    high_val += commit_size

        db_cursor.close()

        return success

    # Insert in sqlite DB with auto increment ID returned
    def sqlite_insert_with_id_returned(self, db_conn, insert_sql, query_data):
        """
        Inserts data and returns the last inserted row ID.

        Args:
            db_conn (sqlite3.Connection): Active SQLite database connection.
            insert_sql (str): The SQL INSERT statement.
            query_data (tuple): Data to insert.

        Returns:
            tuple: (success, last_inserted_id)
        """

        success = True
        db_cursor = db_conn.cursor()
        returned_id = None
        try:
            db_cursor.execute(insert_sql, query_data)
        except Exception as e:
            success = False
            self._logger.exception(f"Query failed because")
            self._logger.error(f"Query was : {insert_sql}")
        else:
            db_conn.commit()
            returned_id = db_cursor.lastrowid

        db_cursor.close()

        return success, returned_id
