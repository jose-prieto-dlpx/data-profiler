from pathlib import Path

def validate_sqlite_connection_config(sqlite_details, exit_on_error, check_and_create_directory, purpose='sqlite'):
    """
    Validates and populates sqlite specific connection configurations

    Args:
        sqlite_details (dict): The dictionary of sqlite connection details read from configuration source.
                               The dictionary is expected to have below keys:
                                db_name (str): The name of the sqlite database.
                                db_directory (str): The directory where the sqlite database is or will be located.
        exit_on_error (ConfigAndLogUtilities.exit_on_error): A function to call for exiting on error.
        check_and_create_directory (ConfigAndLogUtilities.check_and_create_directory):  A function to check and create
                                                                                        directory if not exists.
        purpose (str) : The purpose of validation, eg: Repository, Source, Target etc.

    Raises:
        SystemExit: If any required sqlite configuration is missing or invalid.

    Returns:
        None. The method modifies the input sqlite_details dictionary in-place

    """

    db_name = sqlite_details.get('db_name')
    db_directory = sqlite_details.get('database_directory')
    if not db_name:
        exit_on_error(msg=f'sqlite db name is missing in config for : {purpose}')

    if not db_directory:
        exit_on_error(msg=f"Database directory is not defined in the config for : {purpose}")

    db_directory = Path(db_directory.strip())

    if check_and_create_directory(db_directory):
        sqlite_db = Path(db_directory) / f"{db_name}"
        sqlite_details['sqlite_db'] = sqlite_db
        if sqlite_db.exists():
            sqlite_details['db_exists'] = True
        else:
            sqlite_details['db_exists'] = False