import sqlite3


class SQLiteConnectionManager:

    """
        This class models all the methods needed to manage connectivity to a sqlite database
    """

    # Initialize
    def __init__(self, logger):
        """
        Initializes the SQLiteConnectionManager with configuration and logger.

        Args:
            logger (logging.Logger): Logger for diagnostic output.
        """

        self._logger = logger
        self._logger.debug('Initiating SQLite Connection Manager')

    # Establish connection to sqlite db
    def get_sqlite_connection(self, connection_dict):
        """
        Establishes a connection to the SQLite database.

        Args:
            connection_dict (dict): Dictionary containing the key 'sqlite_db' with a Path to the DB file.

        Returns:
            Optional[sqlite3.Connection]: Connection object if successful, else None.
        """

        try:
            self._logger.info('Initiating connection to repository db')
            sqlite_db = connection_dict['sqlite_db'].absolute()
            db_conn = sqlite3.connect(sqlite_db, timeout=10)
        except sqlite3.DatabaseError as de:
            self._logger.exception(f'Failed to connect to repository db')
            return None
        except Exception:
            self._logger.exception(f'Failed to connect to repository db')
            return None

        self._logger.info('Successfully connected to repository db')
        return db_conn


    # Close connection to repository db
    def close_sqlite_connection(self, db_conn):
        """
        Closes the SQLite connection gracefully.

        Args:
            db_conn (sqlite3.Connection): Active connection to close.

        Returns:
            bool: True if closed successfully, False otherwise.
        """

        try:
            db_conn.close()
        except Exception as e:
            self._logger.exception(f"Failed to close connection to sqlite")
            return False
        else:
            self._logger.info("Closed connection to sqlite database")
            return True