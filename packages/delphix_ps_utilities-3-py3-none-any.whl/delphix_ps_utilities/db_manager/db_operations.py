from delphix_ps_utilities.db_manager.sqlite_modules.db_operations import SQLiteDbOperations
from delphix_ps_utilities.db_manager.oracle_modules.db_operations import OracleDBOperations
from delphix_ps_utilities.db_manager.postgresql_modules.db_operations import PostgreSQLDBOperations

class DBOperations(
    SQLiteDbOperations,
    OracleDBOperations,
    PostgreSQLDBOperations
):
    """
    Common interface for executing database operations (SELECT, DML/DDL, INSERT) across supported platforms.

    Supports:
        - SQLite
        - Oracle
        - PostgreSQL

    Attributes:
        _platform (str): Lowercase name of the platform (e.g., 'sqlite', 'oracle').
        _logger (logging.Logger): Logger instance.
    """

    def __init__(self, platform, logger, properties=None):
        """
        Initializes the DBOperations class with platform-specific configuration.

        Args:
            properties (dict): An optional dictionary specifying connection properties.
            platform (str): Target platform ('sqlite', 'oracle').
            logger (logging.Logger): Logger for diagnostics.
        """


        self._platform = platform.lower()
        self._logger = logger
        if self._platform == 'sqlite':
            SQLiteDbOperations.__init__(self, logger, properties=properties)
        elif self._platform == 'oracle':
            OracleDBOperations.__init__(self, logger, properties=properties)
        elif self._platform == 'postgres':
            PostgreSQLDBOperations.__init__(self, logger, properties=properties)
        else:
            self._logger.error(f'Platform {self._platform} is not supported')

    def db_select(self, db_conn, select_sql, query_data=(), desc_needed=False):
        """
        Executes a SELECT query using the appropriate database platform.

        Args:
            db_conn: Active database connection.
            select_sql (str): SQL query string using <bind> placeholders.
            query_data (tuple, optional): Parameters for the SQL query.
            desc_needed (bool, optional): Whether to return column names.

        Returns:
            tuple:
                - bool, data, rowcount: For desc_needed=False. rowcount is specific to postgresql
                - bool, data, rowcount, column_names: For desc_needed=True. rowcount is specific to postgresql
        """

        if self._platform == 'sqlite':
            self._logger.info('Attempting to execute select against sqlite')
            select_sql = self.prepare_sql(select_sql)
            return self.sqlite_select(db_conn, select_sql, query_data=query_data, desc_needed=desc_needed)
        elif self._platform == 'oracle':
            self._logger.info('Attempting to execute select against oracle')
            select_sql = self.prepare_sql(select_sql)
            return self.oracle_select(db_conn, select_sql, query_data=query_data, desc_needed=desc_needed)
        elif self._platform == 'postgres':
            self._logger.info('Attempting to execute select against postgres')
            select_sql = self.prepare_sql(select_sql)
            return self.postgresql_select(db_conn, select_sql, bind_values=query_data, desc_needed=desc_needed)
        else:
            self._logger.error(f'Platform {self._platform} is not supported')
            return None

    def db_dml_or_ddl(self, db_conn, sql, query_data=None):
        """
        Executes a DML (INSERT/UPDATE/DELETE) or DDL (CREATE/DROP) SQL statement.

        Args:
            db_conn: Active database connection.
            sql (str): SQL query string using <bind> placeholders.
            query_data (list or tuple, optional): Parameters for batch execution.

        Returns:
            bool: True if execution succeeds, False otherwise.
            rowcount: Count of rows updates, specific to postgresql only
        """

        if self._platform == 'sqlite':
            self._logger.info('Attempting to execute ddl/dml against sqlite')
            sql = self.prepare_sql(sql)
            return self.sqlite_dml_or_ddl( db_conn, sql, query_data=query_data)
        elif self._platform == 'oracle':
            self._logger.info('Attempting to execute ddl/dml against oracle repository')
            sql = self.prepare_sql(sql)
            return self.oracle_dml_or_ddl(db_conn, sql, query_data=query_data)
        elif self._platform == 'postgres':
            self._logger.info('Attempting to execute ddl/dml against postgres')
            sql = self.prepare_sql(sql)
            return self.postgresql_dml_or_ddl(db_conn, sql, bind_values=query_data)
        else:
            self._logger.error(f'Platform {self._platform} is not supported')
            return None

    def db_insert_with_id_returned(self, db_conn, sql, query_data):
        """
        Executes an INSERT statement and returns the last inserted ID.

        Args:
            db_conn: Active database connection.
            sql (str): SQL INSERT statement with <bind> placeholders.
            query_data (tuple): Insert data values.

        Returns:
            tuple: (bool, int or None) where the second element is the last inserted ID.
        """

        if self._platform == 'sqlite':
            self._logger.info('Attempting to execute insert with id returned against sqlite')
            sql = self.prepare_sql(sql)
            return self.sqlite_insert_with_id_returned(db_conn, sql, query_data)
        elif self._platform == 'oracle':
            sql = self.prepare_sql(sql)
            self._logger.info('Attempting to execute insert with id returned against oracle')
            return self.oracle_insert_with_id_returned(db_conn, sql, query_data)
        elif self._platform == 'postgres':
            sql = self.prepare_sql(sql)
            self._logger.info('Attempting to execute insert with id returned against postgres')
            return self.postgresql_insert_with_id_returned(db_conn, sql, query_data)
        else:
            self._logger.error(f'Platform {self._platform} is not supported')
            return None

    def prepare_sql(self, sql):
        """
        Converts placeholder tokens (<bind>) into platform-specific parameter markers.

        Args:
            sql (str): SQL query string with <bind> placeholders.

        Returns:
            str: Transformed SQL string using platform-specific placeholders:
                 - SQLite: '?'
                 - Oracle: ':1', ':2', etc.
                 - PostgreSQL: '%s'
        """

        if self._platform.lower() == 'sqlite':
            sql = sql.replace('<bind>', '?')
        elif self._platform.lower() == 'oracle':
            num_replacements = sql.count('<bind>')
            for r in range(num_replacements):
                sql = sql.replace('<bind>', f':{r+1}', 1)
        elif self._platform == 'postgres':
            sql = sql.replace('<bind>', '%s')

        return sql
