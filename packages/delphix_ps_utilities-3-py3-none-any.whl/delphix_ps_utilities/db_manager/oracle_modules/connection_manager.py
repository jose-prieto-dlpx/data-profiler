import oracledb


class OracleConnectionManager:
    """
    This class models all the methods needed to manage connectivity to an oracle database
    """

    # Initialize
    def __init__(self, logger, use_thick_client=False):
        """
        Initializes the OracleConnectionManager with configuration and logger.

        Args:
            logger (logging.Logger): Logger for diagnostic output.
            use_thick_client (bool): If true, uses a full Oracle client installation, else uses a thin client
        """

        self._logger = logger
        self._logger.debug('Initiating Oracle Connection Manager')
        if use_thick_client:
            oracledb.init_oracle_client()

    # Establish connection to oracle db
    def get_oracle_connection(self, connection_dict):
        """
        Establishes a connection to the Oracle database.

        Args:
            connection_dict (dict): Dictionary containing the properties needed to connect to Oracle DB. Expects following
                                    keys:
                                        username (str): Username for authentication.
                                        password (str): Password for authentication.
                                        host (str): Hostname or IP address of the Oracle DB server.
                                        port (int): Port number for the Oracle DB service.
                                        sid_or_service_name (str): SID or service name of the Oracle DB.
                                        use_sid (bool): If true, uses SID for connection, else uses service name.

        Returns:
            Optional[oracledb.Connection]: Connection object if successful, else None.
        """

        self._logger.debug('Creating oracle connection parameters')

        success, connection_params = self.get_oracle_connection_params(connection_dict)

        if not success:
            self._logger.error('Error in creating connection parameters')
            return None

        try:
            self._logger.info('Initiating connection to Oracle DB')
            db_conn = oracledb.connect(params=connection_params)
        except Exception:
            self._logger.exception(f"Connection to oracle database failed")
            return None
        else:
            self._logger.info(f"Successfully connected to Oracle DB")
            return db_conn

    @staticmethod
    def get_oracle_connection_params(connection_dict):
        """
        Builds Oracle connection parameters based on SID or service name.

        Args:
            connection_dict (dict): Oracle connection details.

        Returns:
            tuple: (success flag, ConnectParams object or None)
        """

        if connection_dict['use_sid']:
            connection_params = oracledb.ConnectParams(
                user=connection_dict['username'],
                password=connection_dict['password'],
                host=connection_dict['host'],
                port=connection_dict['port'],
                sid=connection_dict['sid_or_service_name']
            )
            return True, connection_params
        else:
            connection_params = oracledb.ConnectParams(
                user=connection_dict['username'],
                password=connection_dict['password'],
                host=connection_dict['host'],
                port=connection_dict['port'],
                service_name=connection_dict['sid_or_service_name'])
            return True, connection_params


    def close_oracle_connection(self, db_conn):
        """
        Closes the Oracle connection gracefully.

        Args:
            db_conn (oracledb.Connection): Active connection to close.

        Returns:
            bool: True if closed successfully, False otherwise.
        """

        try:
            db_conn.close()
        except Exception as e:
            self._logger.exception(f"Failed to close connection to oracle")
            return False
        else:
            self._logger.info("Closed connection to oracle database")
            return True