class OracleDBOperations:
    """
    Handles basic Oracle operations including SELECT, DML/DDL, and INSERT with ID return.

    Attributes:
        _properties (dict): Configuration properties for DB operations.
        _logger (logging.Logger): Logger instance for logging messages.

    """

    _properties = {
        'commit_size': 10000,
        'read_batch_size': 50000
    }

    def __init__(self, logger, properties=None):
        """
       Initializes the OracleDBOperations with configuration and logger.

       Args:
           properties (dict): A dictionary providing DB connection properties for Oracle
           logger (logging.Logger): Logger instance for logging messages.
       """
        self._logger = logger
        self._properties = self._properties | (properties if properties else {})


    def oracle_select(self, db_conn, select_sql, query_data=(), desc_needed=False):
        """
        Executes a SELECT query on the database.

        Args:
            db_conn (oracledb.Connection): Active Oracle database connection.
            select_sql (str): The SQL SELECT statement to execute.
            query_data (tuple, optional): Data to substitute in the query.
            desc_needed (bool, optional): Whether to return column names.

        Returns:
            tuple: (success, result) or (success, result, column_names)
        """

        db_cursor = db_conn.cursor()
        read_batch_size = self._properties.get('read_batch_size', 50000)
        db_cursor.arraysize = read_batch_size
        success = True
        try:
            self._logger.debug(f'Executing query : {select_sql}')
            if query_data:
                self._logger.debug(f'Query data is : ')
                self._logger.debug(query_data)
            query_result = db_cursor.execute(select_sql, query_data).fetchall()
        except Exception as e:
            success = False
            self._logger.exception(f"Query failed")
            self._logger.error(f"Query was : {select_sql}")
            db_cursor.close()
            if desc_needed:
                return success, None, None
            else:
                return success, None
        else:
            if desc_needed:
                col_names = [row[0] for row in db_cursor.description]
                db_cursor.close()
                return success, query_result, col_names
            else:
                db_cursor.close()
                return success, query_result

    def oracle_dml_or_ddl(self, db_conn, sql, query_data=None):
        """
        Executes a DML or DDL operation, with optional batching.

        Args:
            db_conn (oracledb.Connection): Active Oracle database connection.
            sql (str): The SQL statement to execute.
            query_data (list, optional): List of tuples to use with executemany.

        Returns:
            bool: True if successful, False otherwise.
        """

        commit_size = self._properties.get('commit_size', 10000)
        db_cursor = db_conn.cursor()
        success = True
        self._logger.debug(f'Executing query : {sql}')
        if not query_data:
            try:
                db_cursor.execute(sql)
            except Exception as e:
                success = False
                self._logger.exception(f"Query failed because")
                self._logger.error(f"Query was : {sql}")
            else:
                db_conn.commit()
        else:
            low_val = 0
            high_val = commit_size
            while True:
                batch_data = query_data[low_val:high_val]
                self._logger.debug(f'2 sample rows for dml : ')
                self._logger.debug(batch_data[:2])
                try:
                    db_cursor.executemany(sql, batch_data)
                except Exception as e:
                    success = False
                    self._logger.exception(f"Query failed because")
                    self._logger.error(f"Query was : {sql}")
                    self._logger.error(f"Failure row range : {low_val}, {high_val}")
                    break
                else:
                    db_conn.commit()
                    batch_data.clear()
                    if high_val >= len(query_data):
                        break

                    low_val = high_val
                    high_val += commit_size

        db_cursor.close()

        return success

    def oracle_insert_with_id_returned(self, db_conn, insert_sql, query_data):
        """
        Inserts data and returns the last inserted row ID.

        Args:
            db_conn (oracledb.Connection): Active Oracle database connection.
            insert_sql (str): The SQL INSERT statement.
            query_data (tuple): Data to insert.

        Returns:
            tuple: (success, last_inserted_id)
        """

        success = True
        db_cursor = db_conn.cursor()
        new_id = db_cursor.var(int)
        new_query_data = query_data + (new_id,)
        returned_id = None
        try:
            db_cursor.execute(insert_sql, new_query_data)
        except Exception as e:
            success = False
            self._logger.exception(f"Query failed because")
            self._logger.error(f"Query was : {insert_sql}")
        else:
            db_conn.commit()
            returned_id = new_id.getvalue()

        db_cursor.close()

        return success, returned_id