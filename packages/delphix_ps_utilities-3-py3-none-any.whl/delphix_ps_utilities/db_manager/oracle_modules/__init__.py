def validate_oracle_connection_config(oracle_details, exit_on_error, purpose='Oracle'):
    """
    Validates and populates oracle specific connection configurations

    Args:
        oracle_details (dict): The dictionary of oracle connection details read from configuration source
                               The dictionary is expected to have below keys:
                                host (str): The hostname or IP address of the Oracle database server.
                                port (int): The port number on which the Oracle database server is listening.
                                use_sid (bool): Whether to use SID or Service Name for connection.
                                sid_or_service_name (str): The SID or Service Name of the Oracle database.
                                username (str): The encrypted username for connecting to the Oracle database.
                                password (str): The encrypted password for connecting to the Oracle database.
        exit_on_error (ConfigAndLogUtilities.exit_on_error): A function to call for exiting on error.
        purpose (str) : The purpose of validation, eg: Repository, Source, Target etc.

    Raises:
            SystemExit: If any required repository configuration is missing or invalid.

    """

    missing_keys = []
    for attribute in ['host', 'port', 'use_sid', 'sid_or_service_name', 'username', 'password']:
        if oracle_details.get(attribute, None) is None:
            missing_keys.append(attribute)

    if missing_keys:
        exit_on_error(msg=f'Some attributes are not defined in connection dictionary for {purpose}, '
                          f'missing attributes: {missing_keys}')
