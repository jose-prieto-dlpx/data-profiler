def validate_postgres_connection_config(postgres_details, exit_on_error, purpose='Postgres'):
    """
    Validates and populates postgres specific connection configurations

    Args:
        postgres_details (dict): The dictionary of PostgreSQL connection details read from configuration source
                                 The dictionary is expected to have some of the below keys:
                                    host (str): The hostname or IP address of the Oracle database server.
                                    port (int): The port number on which the Oracle database server is listening.
                                    database_name (str): Name of the database to connect to.
                                    dsn (str): The DSN to use for connection.
                                    is_dsn (bool): Whether to use DSN or individual parameters for connection.
                                    ssl_mode (str): SSL mode to use for the connection. Defaults to 'prefer' if not provided.
                                    username (str): The encrypted username for connecting to the Oracle database.
                                    password (str): The encrypted password for connecting to the Oracle database.
        exit_on_error (ConfigAndLogUtilities.exit_on_error): A function to call for exiting on error.
        purpose (str) : The purpose of validation, eg: Repository, Source, Target etc.

    Raises:
        SystemExit: If any required repository configuration is missing or invalid.

    Returns:
        None. It modifies the input postgres_details dictionary in-place

    """

    if postgres_details.get('is_dsn', None) is None:
        # Assume DSN to connect
        if postgres_details.get("dsn", None) is None or not postgres_details.get("dsn"):
            exit_on_error(
                msg=f"is_dsn wasn't defined in connection config, assumed DSN should be used but "
                    f"DSN string not provided in connection dictionary for {purpose}, cannot establish connection."
            )

        postgres_details['is_dsn'] = True

    elif postgres_details.get('is_dsn'):
        if postgres_details.get("dsn", None) is None or not postgres_details.get("dsn"):
            exit_on_error(
                msg=f"is_dsn is set to true in connection config, but DSN string not provided in connection "
                    f"dictionary for {purpose}, cannot establish connection."
            )

    else:
        missing_keys = []
        for attribute in ['host', 'port', 'database_name', 'username', 'password']:
            if not postgres_details.get(attribute, None):
                missing_keys.append(attribute)

        if missing_keys:
            exit_on_error(msg=f'Some keys are not defined in postgres_details for {purpose}, '
                                   f'Missing keys: {missing_keys}')

        if postgres_details.get('ssl_mode', None) is None or not postgres_details.get('ssl_mode'):
            postgres_details['ssl_mode'] = 'prefer'
        else:
            postgres_details['ssl_mode'] = postgres_details.get('ssl_mode').strip()
