from psycopg.rows import dict_row

class PostgreSQLDBOperations:
    """
    Handles basic PostgreSQL operations including SELECT, DML/DDL, and INSERT with ID return.

    Attributes:
        _properties (dict): Configuration properties for DB operations.
        _logger (logging.Logger): Logger instance for logging messages.

    """

    _properties = {
        'commit_size': 10000,
        'read_batch_size': 50000
    }

    def __init__(self, logger, properties=None):
        """
       Initializes the OracleDBOperations with configuration and logger.

       Args:
           properties (dict): A dictionary providing DB connection properties for Oracle
           logger (logging.Logger): Logger instance for logging messages.
       """
        self._logger = logger
        self._properties = self._properties | (properties if properties else {})



    def postgresql_select(self, db_conn, select_sql, bind_values=(), desc_needed=False):
        """
        Executes a SELECT query on the database.

        Args:
            db_conn (psycopg2.Connection): Active PostgreSQL database connection.
            select_sql (str): The SQL SELECT statement to execute.
            bind_values (tuple, optional): Data to substitute in the query.
            desc_needed (bool, optional): Whether to return column names.

        Returns:
            tuple: (success, result, rowcount) or (success, result, rowcount, column_names)
        """
        db_cursor = db_conn.cursor(row_factory=dict_row)
        db_cursor.arraysize = self._properties.get("read_batch_size", 50000)
        success = True
        try:
            self._logger.debug(f"Executing query : {select_sql}")
            if bind_values:
                self._logger.debug(f"Bind values are : {bind_values}")
                db_cursor.execute(select_sql, bind_values)
            else:
                db_cursor.execute(select_sql)
            query_result = db_cursor.fetchall()
            rowcount = db_cursor.rowcount
            self._logger.debug(f'Query executed successfully and returned {rowcount} rows.')
        except Exception as excp:
            success = False
            self._logger.exception(f"Query failed : {excp}")
            self._logger.error("Query was : {select_sql}")
            db_cursor.close()
            if desc_needed:
                return success, None, None, None
            else:
                return success, None, None
        else:
            if desc_needed:
                col_names = [row[0] for row in db_cursor.description]
                db_cursor.close()
                return success, query_result, rowcount, col_names
            else:
                db_cursor.close()
                return success, query_result, rowcount


    def postgresql_dml_or_ddl(self, db_conn, sql, bind_values=()):
        """
        Executes a DML or DDL operation, with optional batching.

        Args:
            db_conn (psycopg2.Connection): Active PostgreSQL database connection.
            sql (str): The SQL statement to execute.
            bind_values (list, optional): List of tuples to use with executemany.

        Returns:
            bool: True if successful, False otherwise.
            rowcount: Count of rows updated/affected.
        """

        commit_size = self._properties.get("commit_size", 10000)
        arraysize = self._properties.get("read_batch_size", 50000)
        self._logger.debug(f"Commit size is {commit_size}")
        self._logger.debug(f"Array size is {arraysize}")

        db_cursor = db_conn.cursor()
        success = True
        self._logger.debug(f"Executing query : {sql}")
        try:
            if bind_values:
                if isinstance(bind_values, list):
                    db_cursor.executemany(sql, bind_values)
                elif isinstance(bind_values, tuple):
                    db_cursor.execute(sql, bind_values)
                else:
                    db_cursor.execute(sql, bind_values)
            else:
                db_cursor.execute(sql)
        except Exception:
            success = False
            self._logger.exception(f"Query failed")
            self._logger.error(f"Query was : {sql}")
        else:
            db_conn.commit()

        rowcount = db_cursor.rowcount
        db_cursor.close()

        return success, rowcount

    def postgresql_insert_with_id_returned(self, db_conn, insert_sql, bind_values):
        """
        Inserts data and returns the last inserted row ID.

        Args:
            db_conn (psycopg2.Connection): Active Oracle database connection.
            insert_sql (str): The SQL INSERT statement.
            bind_values (tuple): Data to insert.

        Returns:
            tuple: (success, last_inserted_id)
        """

        success = True
        db_cursor = db_conn.cursor()
        new_id = db_cursor.var(int)
        new_query_data = bind_values + (new_id,)
        returned_id = None
        try:
            db_cursor.execute(insert_sql, new_query_data)
        except Exception:
            success = False
            self._logger.exception(f"Query failed ")
            self._logger.error(f"Query was : {insert_sql}")
        else:
            db_conn.commit()
            returned_id = new_id.getvalue()

        db_cursor.close()

        return success, returned_id