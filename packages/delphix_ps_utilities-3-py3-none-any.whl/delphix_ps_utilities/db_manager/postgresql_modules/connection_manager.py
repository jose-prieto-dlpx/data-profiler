import psycopg as pg


class PostgreSQLConnectionManager:
    """
    This class models all the methods needed to manage connectivity to a postgresql database
    """

    # Initialize
    def __init__(self, logger, connection_timeout=90):
        """
        Initializes the PostgreSQLConnectionManager with logger.

        Args:
            logger (logging.Logger): Logger for diagnostic output.
            connection_timeout (int): Timeout in seconds to wait for a connection

        """
        self._logger = logger
        self._logger.debug("Initiating PostgreSQL Connection Manager")
        self._connection_timeout = connection_timeout

    # Establish connection to postgresql db
    # TODO : Ensure that we can connect over TLS for which we may need a certificate file to be available. This means we may have to add another configuration variable to get this certificate and establish the sslmode for the DB connections
    # TODO : Add a configuration items for PostgreSQL connection parameters. Initially a DSN with unencrypted password from a vault. Add later an encrypted password parameter in the configuration file to be added to the DSN after decryption.
    # TODO : Add alternative connection methods as needed.

    def get_postgresql_connection(self, connection_dict):
        """
            Establishes a connection to the PostgreSQL database.

            Args:
                connection_dict (dict): Dictionary containing the properties needed to connect to PostgreSQL DB.
                                        Expects some of the following keys:
                                            is_dsn (bool): A flag indicating if dsn should be used to connect.
                                            dsn (str): DSN to be used for connection.
                                            database_name (str): Name of the database.
                                            host (str): Hostname or IP address of the database host
                                            port (int): Port number for the PostgreSQL service.
                                            username (str): Username for the database.
                                            password (str): Password for the database.
                                            ssl_mode (str): SSL mode to use for the connection. Defaults to 'prefer' if not provided.

            Returns:
                Optional[psycopg.Connection]: Connection object if successful, else None.
            """

        self._logger.info(
            f"Establishing a connection to the PostgreSQL database. Timeout is {self._connection_timeout} seconds."
        )

        if connection_dict.get('is_dsn', None) is None:
            self._logger.warning(
                f"is_dsn flag not defined in connection dictionary, assuming DSN string to connect to the database."
            )
            if connection_dict.get("dsn", None) is None or connection_dict.get("dsn"):
                self._logger.error(
                    f"DSN string not provided in connection dictionary, cannot establish connection."
                )
                return None
            else:
                dsn = connection_dict.get("dsn")
        else:
            if connection_dict.get("is_dsn"):
                dsn = connection_dict.get("dsn")
            else:
                parameters_list = [
                    "database_name",
                    "host",
                    "port",
                    "username",
                    "password"
                ]
                missing_keys = []
                for parameter in parameters_list:
                    if parameter not in connection_dict:
                        missing_keys.append(parameter)

                all_keys_present = len(missing_keys) == 0
                if not all_keys_present:
                    self._logger.error(
                        f"At least one mandatory parameter is not in the connection dictionary, "
                        f"please add the missing one(s): {missing_keys}"
                    )
                    return None

                if connection_dict.get("ssl_mode", None) is None or not connection_dict.get("ssl_mode"):
                    ssl_mode = "prefer"
                else:
                    ssl_mode = connection_dict.get("ssl_mode")

                dsn = f'dbname={connection_dict["database_name"]} host={connection_dict["host"]} port={connection_dict["port"]} user={connection_dict["username"]} password={connection_dict["password"]} sslmode={ssl_mode} connect_timeout={self._connection_timeout}'

        try:
            db_conn = pg.connect(dsn)
        except Exception:
            self._logger.exception(f"Connection to PostreSQL database failed.")
            return None
        else:
            self._logger.info(f"Successfully connected to PostreSQL DB")
            return db_conn

    def close_postgresql_connection(self, db_conn):
        """
        Closes the PostgreSQL connection gracefully.

        Args:
            db_conn (psycopg2.Connection): Active connection to close.

        Returns:
            bool: True if closed successfully, False otherwise.

        """
        try:
            db_conn.close()
        except Exception:
            self._logger.exception(f"Failed to close connection to PostgreSQL")
            return False
        else:
            self._logger.info("Closed connection to PostgreSQL database")
            return True