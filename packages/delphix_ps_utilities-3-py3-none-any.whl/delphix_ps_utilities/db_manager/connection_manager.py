from delphix_ps_utilities.db_manager.sqlite_modules.connection_manager import SQLiteConnectionManager
from delphix_ps_utilities.db_manager.oracle_modules.connection_manager import OracleConnectionManager
from delphix_ps_utilities.db_manager.postgresql_modules.connection_manager import PostgreSQLConnectionManager


class DBConnectionManager(
    SQLiteConnectionManager,
    OracleConnectionManager,
    PostgreSQLConnectionManager
):

    """
        This class models all the methods needed to manage connectivity to a supported database platform

        Inherits:
            SQLiteConnectionManager: Connection Manager for sqlite DB
            OracleConnectionManager: Connection Manager for oracle DB
            PostgreSQLConnectionManager: Connection Manager for postgresql DB
    """

    # Initialize
    def __init__(self, logger, platform, use_thick_client=False, connection_timeout=90):
        """
        Initializes the appropriate database connection manager.

        Args:
            logger (logging.Logger): Logger for diagnostics.
            platform (str): Target database platform.
            use_thick_client (bool): Only applicable for Oracle.
                                    If true, uses a full Oracle client installation, else uses a thin client
            connection_timeout (int): Only applicable for postgresql
                                      Connection timeout in seconds.
        """

        self._logger = logger
        self._platform = platform.lower()
        if self._platform == 'sqlite':
            SQLiteConnectionManager.__init__(self, logger)
        elif self._platform == 'oracle':
            OracleConnectionManager.__init__(self, logger, use_thick_client)
        elif self._platform == 'postgres':
            PostgreSQLConnectionManager.__init__(self, logger, connection_timeout)
        else:
            self._logger.error(f'Platform {self._platform} is not supported. Only sqlite, oracle and postgres are supported')

    def get_connection(self, connection_dict):
        """
        Creates a new database connection based on platform.

        Args:
            connection_dict (dict): Dictionary of connection parameters.

        Returns:
            db_conn or None: Open database connection or None if failed/unsupported.
        """

        if self._platform == 'sqlite':
            self._logger.info('Attempting to create connection to sqlite')
            return self.get_sqlite_connection(connection_dict)
        elif self._platform == 'oracle':
            self._logger.info('Attempting to create connection to oracle')
            return self.get_oracle_connection(connection_dict)
        elif self._platform == 'postgres':
            self._logger.info('Attempting to create connection to postgres')
            return self.get_postgresql_connection(connection_dict)
        else:
            self._logger.error(
                f'Platform : {self._platform} is not supported. Only sqlite, oracle and postgres are supported'
            )
            return None

    def close_connection(self, db_conn):
        """
        Closes the open database connection gracefully.

        Args:
            db_conn: The open database connection to close.

        Returns:
            bool: True if closed successfully, False otherwise.
        """

        if self._platform == 'sqlite':
            self._logger.debug('Closing connection to sqlite database')
            return self.close_sqlite_connection(db_conn)
        elif self._platform == 'oracle':
            self._logger.debug('Closing connection to oracle database')
            return self.close_oracle_connection(db_conn)
        elif self._platform == 'postgres':
            self._logger.debug('Closing connection to postgres database')
            return self.close_postgresql_connection(db_conn)
        else:
            self._logger.error(
                f'Platform : {self._platform} is not supported. Only sqlite and oracle are supported'
            )
            return None
