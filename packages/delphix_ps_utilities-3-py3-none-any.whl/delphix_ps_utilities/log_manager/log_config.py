import logging
from logging.handlers import TimedRotatingFileHandler, QueueHandler
import os
import threading
import gzip
import time
import json

from delphix_ps_utilities.log_manager.log_context import log_context


class JSONFormatter(logging.Formatter):
    """
    This class models a custom JSON Formatter

    Attributes:

        _timestamp_format (str) : Specifies the timestamp format to use in logging

    Inherits:

        Formatter: THe default Formatter for logging

    """

    _timestamp_format = '%Y-%m-%dT%H:%M:%SZ'

    def __init__(self, format_specification):
        """
        Initializes the JSONFormatter class

        Args:
            format_specification (dict) : A dictionary specifying log format

        """

        self._format_specification = format_specification

        super().__init__()
        self.converter = time.gmtime

    def format(self, record):
        """
        Defines the format for log messages

        Args:
            record (logging.LogRecord) : An instance of LogRecord class representing an attempted logged message

        Returns:
            (str): A formatted string, in this case a JSON string specifically

        """

        if record.exc_info and not record.exc_text:
            record.exc_text = self.formatException(record.exc_info)

        final_message = {}


        for key, value in self._format_specification.items():
            if key == 'format_type':
                continue

            if key == 'timestamp_format' and value:
                self._timestamp_format = value
                continue

            if key == 'asctime':
                record.asctime = self.formatTime(record, self._timestamp_format)
                final_message['timestamp'] = record.asctime
            elif key == 'message':
                final_message[key] = record.msg
                if record.exc_text:
                    final_message['traceback'] = record.exc_text
                else:
                    final_message['traceback'] = None

            else:
                if getattr(record, key, None):
                    final_message[key] = getattr(record, key, None)

        return json.dumps(final_message)

class LogConfig:
    """
    This class handles logging

    Attributes:

        _log_format_specification (dict): Defines the format of log messages
        _log_timestamp_format (str): Defines timestamp format for logging
        _old_factory (logging.LogRecord) : Defines the existing LogRecord

    """

    _log_timestamp_format = '%Y-%m-%dT%H:%M:%SZ'

    _log_format_specification = {
        'format_type' : 'classic',
        'timestamp_format' : '%Y-%m-%dT%H:%M:%SZ',
        'asctime' : '22s',
        'module' : '50s',
        'lineno' : '10d',
        'levelname' : '8s',
        'message' : 's'
    }
    # log_format = f"%(asctime)-22s %(module)-50s %(lineno)-10d %(levelname)-8s %(message)s"

    _old_factory = logging.getLogRecordFactory()

    # Initialize
    def __init__(self, debug=False, log_mode='file', log_format_specification=None, log_setup=None):
        """
        Initializes the LogConfig class

        Args:
            debug (book) : A boolean indicating if log level should be DEBUG or INFO
            log_format_specification (dict) : A dictionary specifying the format for log messages
            log_mode (str) : A string indicating the log mode to use. Default is file based logging
            log_setup (dict) : A dictionary specifying the log setup parameters such as log_file, queue etc.

        """

        self._log_mode = log_mode
        self._log_setup = log_setup

        if log_format_specification:
            self._log_format_specification = log_format_specification

        if self._log_format_specification.get('format_type'):
            format_type = self._log_format_specification['format_type']
        else:
            format_type = 'classic'

        if format_type == 'json':
            self._format_type = 'json'
            # self._log_format = self.log_format_definition
        else:
            self._format_type = 'classic'
            self._log_format = ''
            for key, value in self._log_format_specification.items():
                if key == 'format_type':
                    continue

                if not value:
                    continue

                if key == 'timestamp_format':
                    self._log_timestamp_format = value
                    continue

                self._log_format = f'{self._log_format}%({key})-{value} '

            self._log_format.rstrip()


        if debug:
            self._log_level = logging.DEBUG
        else:
            self._log_level = logging.INFO

    # Add custom fields to log record
    def setup_record_factory(self):
        """
        Sets up LogRecord by adding custom fields

        Returns:
            record (LogRecord) : The updated record with custom fields added

        """
        def record_factory(*args, **kwargs):
            record = self._old_factory(*args, **kwargs)
            custom_fields = log_context.get_all()
            for key, value in custom_fields.items():
                setattr(record, key, value)

            return record

        return record_factory

    # ToDo: Add filter to exclude sensitive information from logs
    # Setup logging
    def setup_logging(self):
        """
        Sets up a logging instance with the specified handler and formatting options.

        Returns:
            logger (logging.Logger) : The instance of Logger setup to log messages
            handler (logging.handlers.*) : The instance of handler

        Raises:
            ValueError: If `handler_type` is 'queue' and no queue is provided.

        """
        log_setup = self._log_setup
        log_mode = self._log_mode
        if log_mode not in ['console'] and not log_setup:
            print('Error: No log setup provided')
            return None, None

        if self._log_mode == 'file':
            return self.setup_file_logger()
        elif self._log_mode == 'queue':
            return self.setup_queue_logger()
        elif self._log_mode == 'console':
            return self.setup_console_logger()
        elif self._log_mode == 'azure_insights':
            return self.setup_azure_insights_logger()
        elif self._log_mode == 'gcp_logging':
            return self.setup_gcp_logger()
        else:
            print(f'Error: Invalid log mode {self._log_mode} specified')
            return None, None

    def setup_file_logger(self):
        """
        Sets up file based logging

        Returns:
            logger (logging.Logger) : The instance of Logger setup to log messages
            handler (logging.handlers.TimedRotatingFileHandler) : The instance of TimedRotatingFileHandler
        """

        log_setup = self._log_setup
        log_file = log_setup.get('log_file')
        if not log_file:
            print('Error: No log file provided for file based logging')
            return None, None
        logger_name_prefix = log_setup.get('logger_name_prefix', 'app')
        logger_name = f'{logger_name_prefix}_{os.getpid()}'
        logger = logging.getLogger(logger_name)
        logger.setLevel(self._log_level)

        if logger.hasHandlers():
            while len(logger.handlers) > 0:
                h = logger.handlers[0]
                logger.removeHandler(h)

        handler = TimedRotatingFileHandler(filename=log_file, when="MIDNIGHT", interval=1)
        # set procedure for log rotation and naming for rotated files
        handler.rotator = self.rotator
        handler.namer = self.namer

        logging.setLogRecordFactory(self.setup_record_factory())
        if self._format_type == 'json':
            formatter = JSONFormatter(self._log_format_specification)
        else:
            formatter = logging.Formatter(self._log_format, self._log_timestamp_format)
            formatter.converter = time.gmtime

        handler.setFormatter(formatter)
        logger.addHandler(handler)

        return logger, handler

    def setup_queue_logger(self):
        """
        Sets up queue based logging

        Returns:
            logger (logging.Logger) : The instance of Logger setup to log messages
            handler (QueueHandler) : The instance of QueueHandler

        """

        log_setup = self._log_setup
        queue = log_setup.get('queue')
        if not queue:
            print('Error: No queue provided for queue based logging')
            return None, None
        logger_name_prefix = log_setup.get('logger_name_prefix', 'app')
        logger_name = f'{logger_name_prefix}_{os.getpid()}'
        logger = logging.getLogger(logger_name)
        logger.setLevel(self._log_level)

        handler = QueueHandler(queue)
        logging.setLogRecordFactory(self.setup_record_factory())
        if self._format_type == 'json':
            formatter = JSONFormatter(self._log_format_specification)
        else:
            formatter = logging.Formatter(self._log_format, self._log_timestamp_format)
            formatter.converter = time.gmtime

        handler.setFormatter(formatter)
        logger.addHandler(handler)
        return logger, handler

    def setup_azure_insights_logger(self):
        """
        Sets up Azure Application Insights based logging

        Returns:
            logger (logging.Logger) : The instance of Logger setup to log messages
            handler (logging.handlers.*) : The instance of handler

        """
        print('Azure Application Insights logging is not yet implemented')
        return None, None

    def setup_gcp_logger(self):
        """
        Sets up GCP based logging

        Returns:
            logger (logging.Logger) : The instance of Logger setup to log messages
            handler (logging.handlers.*) : The instance of handler

        """
        print('GCP logging is not yet implemented')
        return None, None

    def setup_console_logger(self):
        """
        Sets up console based logging

        Returns:
            logger (logging.Logger) : The instance of Logger setup to log messages
            handler (logging.StreamHandler) : The instance of StreamHandler

        """
        log_setup = self._log_setup
        logger_name_prefix = log_setup.get('logger_name_prefix', 'app')
        logger_name = f'{logger_name_prefix}_{os.getpid()}'
        logger = logging.getLogger(logger_name)
        logger.setLevel(self._log_level)

        if logger.hasHandlers():
            while len(logger.handlers) > 0:
                h = logger.handlers[0]
                logger.removeHandler(h)

        handler = logging.StreamHandler()

        logging.setLogRecordFactory(self.setup_record_factory())
        if self._format_type == 'json':
            formatter = JSONFormatter(self._log_format_specification)
        else:
            formatter = logging.Formatter(self._log_format, self._log_timestamp_format)
            formatter.converter = time.gmtime

        handler.setFormatter(formatter)
        logger.addHandler(handler)

        return logger, handler


    @staticmethod
    def namer(name):
        return name + ".gz"

    @staticmethod
    def rotator(source, dest):
        with open(source, "rb") as sf:
            data = sf.read()

            with gzip.open(dest, 'wb') as f:
                f.write(data)

        os.remove(source)

    # Close the handler
    @staticmethod
    def close_handler(handler: logging.handlers.TimedRotatingFileHandler) -> None:
        """
        Closes the handler to terminate logging

        Args:
            handler (logging.handlers.TimedRotatingFileHandler) : The handler used for logging to log files

        Returns:
            None

        """
        handler.flush()
        handler.close()
