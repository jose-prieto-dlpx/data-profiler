import threading

class LogContext:
    """
    A class to manage logging context information.

    Attributes:
        _default_context (dict): A dictionary to hold default context.
    """

    _default_context = dict()

    def __init__(self):
        """
        Initialize the LogContext

        """
        self._local = threading.local()
        self._local.context = {}

    def set_defaults(self, custom_fields=None):
        """
        Set default context data.

        Args:
            custom_fields (list): A list providing fields that define a context
        """
        if custom_fields:
            for each_field in custom_fields:
                self._default_context[each_field] = 'N/A'

    def add_context(self, context_data):
        """
        Add a key-value pair to the logging context.

        Args:
            context_data (dict): A dictionary providing context
        """

        if not hasattr(self._local, 'context'):
            self._local.context = {}

        self._local.context.update(context_data)

    def get_all(self):
        """
        Returns a merged dictionary of defaults and current thread context
        Custom values override defaults.
        """

        if not hasattr(self._local, 'context'):
            self._local.context = {}

        # Merge default and context, with context values overriding defaults
        merged = self._default_context.copy()
        merged.update(self._local.context)
        return merged

log_context = LogContext()