class DummyLogger:
    """
    A dummy logger that prints messages to the console instead of logging them.
    This is used when logging is not required or for testing purposes.
    """


    def debug(self, message):
        print(f"DEBUG: {message}")

    def info(self, message):
        print(f"INFO: {message}")

    def warning(self, message):
        print(f"WARNING: {message}")

    def error(self, message):
        print(f"ERROR: {message}")

    def exception(self, message):
        import traceback
        print(f"EXCEPTION: {message}")
        traceback.print_exc()
