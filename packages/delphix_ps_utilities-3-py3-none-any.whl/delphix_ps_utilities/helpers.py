from wsgiref.util import application_uri

import pandas as pd
from typing import Any

from delphix_ps_utilities.db_manager.connection_manager import DBConnectionManager
from delphix_ps_utilities.db_manager.db_operations import DBOperations


class Helpers:
    """
    A collection of helper methods.
    """

    _insert_metadata_inventory_sql = (f"insert into <schema>.metadata_inventory (application_name, "
                                      f"schema_name, database_name, table_name, column_name, data_type, "
                                      f"start_ts) values (<bind>, <bind>, <bind>, <bind>, <bind>, <bind>, <bind>)"
                                      )

    _update_metadata_inventory_sql = (f"update <schema>.metadata_inventory set end_ts = <bind> where "
                                      f"application_name = <bind> and schema_name = <bind> and database_name = <bind> "
                                      f"and table_name = <bind> and column_name = <bind>")


    def refresh_inventory(self, new_inventory, dropped_inventory, modified_inventory, inventory_with_no_change,
                          logger, config_dict):

        """
        This method will update the metadata inventory table based on the provided inventory lists. The method assumes
        that the metadata_inventory table exists in the specified schema and has the appropriate structure. At a
        minimum, the method expects following columns to be present in the metadata_inventory table:
            - application_name
            - schema_name
            - database_name
            - table_name
            - column_name
            - data_type
            - start_ts
            - end_ts

        The method will also establish connection to the repository database based on the received config_dict. The
        method assumes that the config_dict contains a dictionary defined by the key : repository_config
        The repository_config dictionary is expected to contain the following keys:
            - platform (str) : Defines the type of database. Supported values are 'oracle', 'sqlite, 'postgres'
            - A dictionary identified by the key = platform.lower()

        The method also assumes the platform specific connection details are valid and sufficient to establish
        connection

        Args:
            new_inventory (list): List of tuples representing new inventory records to be added.
            dropped_inventory (list): List of tuples representing inventory records to be marked as dropped.
            modified_inventory (list): List of tuples representing inventory records that have been modified.
            inventory_with_no_change (list): List of tuples representing inventory records with no changes.
            logger (logging.Logger): Logger object for logging messages.
            config_dict (dict): Configuration dictionary containing database connection details and schema name.

        Returns:
            bool: True if the operation was successful, False otherwise.

        """

        logger.debug('Starting refresh_inventory method')

        logger.debug(f'New fields to be added to inventory: {len(new_inventory)}')
        logger.debug(f'Dropped fields to be updated in repository: {len(dropped_inventory)}')
        logger.debug(f'Modified fields to be updated in repository: {len(modified_inventory)}')
        logger.debug(f'Fields with no change: {len(inventory_with_no_change)}')

        logger.debug('Establishing connection to repository database')

        platform = config_dict.get('repository_config').get('platform', '').lower()
        db_conn_manager = DBConnectionManager(logger, platform)
        db_ops_manager = DBOperations(platform, logger)
        repo_conn = db_conn_manager.get_connection(config_dict.get('repository_config').get(platform))
        if repo_conn is None:
            logger.error('Failed to establish connection to repository database')
            return False

        repository_schema = config_dict.get('repository_config').get(platform).get('schema_name', 'public')
        application_name = config_dict.get('application_name')
        database_name = config_dict.get('application_connection_details', {}).get('database_name')
        application_schema = config_dict.get('application_connection_details', {}).get('schema_name')
        ts = config_dict.get('raw_session_ts')

        if not application_schema:
            logger.error('Could not find application schema in the config passed')
            return False

        if not database_name:
            logger.error('Could not find database name in the config passed')
            return False

        if not application_name:
            logger.error('Could not find application name in the config passed')
            return False

        insert_sql = self._insert_metadata_inventory_sql.replace('<schema>', repository_schema)
        update_sql = self._update_metadata_inventory_sql.replace('<schema>', repository_schema)

        query_data = []

        # Inserting new records
        if new_inventory:
            for record in new_inventory:
                query_data.append(
                    (
                        application_name,
                        application_schema,
                        database_name,
                        record.get('TABLE_NAME'),  # table_name
                        record.get('COLUMN_NAME'),  # column_name
                        record.get('DATA_TYPE_new'),  # data_type
                        ts          # start_ts
                    )
                )


            success, rowcount = db_ops_manager.db_dml_or_ddl(repo_conn, insert_sql, query_data)
            if not success:
                logger.error('Failed to insert new inventory records into metadata_inventory table')
                db_conn_manager.close_connection(repo_conn)
                return False

            logger.info(f'Inserted {rowcount} new inventory records into metadata_inventory table')

            query_data.clear()

        # Updating dropped records to set an end timestamp indicating they are no longer active
        if dropped_inventory:
            for record in dropped_inventory:
                query_data.append(
                    (
                        ts,         # end_ts
                        application_name,
                        application_schema,
                        database_name,
                        record.get('TABLE_NAME'),  # table_name
                        record.get('COLUMN_NAME')   # column_name
                    )
                )

            success, rowcount = db_ops_manager.db_dml_or_ddl(repo_conn, update_sql, query_data)
            if not success:
                logger.error('Failed to update dropped inventory records in metadata_inventory table')
                db_conn_manager.close_connection(repo_conn)
                return False

            logger.info(f'Updated {rowcount} dropped inventory records in metadata_inventory table')

            query_data.clear()

        # Updating modified records to set an end timestamp for the old record and insert a new record with updated details
        if modified_inventory:
            for record in modified_inventory:
                query_data.append(
                    (
                        ts,         # end_ts
                        application_name,
                        application_schema,
                        database_name,
                        record.get('TABLE_NAME'),  # table_name
                        record.get('COLUMN_NAME')   # column_name
                    )
                )

            success, rowcount = db_ops_manager.db_dml_or_ddl(repo_conn, update_sql, query_data)

            if not success:
                logger.error('Failed to update modified inventory records in metadata_inventory table')
                db_conn_manager.close_connection(repo_conn)
                return False

            logger.info(f'Updated {rowcount} modified inventory records in metadata_inventory table')

            query_data.clear()

            for record in modified_inventory:
                query_data.append(
                    (
                        application_name,
                        application_schema,
                        database_name,
                        record.get('TABLE_NAME'),  # table_name
                        record.get('COLUMN_NAME'),  # column_name
                        record.get('DATA_TYPE_new'),  # data_type
                        ts          # start_ts
                    )
                )

            success, rowcount = db_ops_manager.db_dml_or_ddl(repo_conn, insert_sql, query_data)
            if not success:
                logger.error('Failed to insert updated modified inventory records into metadata_inventory table')
                db_conn_manager.close_connection(repo_conn)
                return False

            logger.info(f'Inserted {rowcount} updated modified inventory records into metadata_inventory table')


        return True

    @staticmethod
    def find_delta(
            existing_inventory,
            new_inventory,
            existing_inventory_columns,
            new_inventory_columns,
            merge_columns,
            no_change_query,
            changed_query
    ):
        """
        Find differences between existing and new inventory, both being list of tuples
        based on specified columns and queries.
        Uses pandas merge and query functionalities.

        The two lists are merged on the specified merge_columns.

        The method assumes that the column names for existing_inventory and new_inventory allows the merge to be
        performed as per the provided merge_columns.
        The method also assumes that the no_change_query and changed_query are valid pandas
        query strings that can be applied to the merged DataFrame.

        _existing and _new suffixes are added to columns from existing_inventory and new_inventory respectively
        in the merged DataFrame, and, therefore, the returned lists will contain these suffixed column names.

        Args:
            existing_inventory (list): First list of tuples to compare. This contains the existing inventory.
            new_inventory (list): Second list of tuples to compare. This contains the new inventory.
            existing_inventory_columns (list): Column names for the first list.
                                               This describes the structure of each tuple in list1.
            new_inventory_columns (list): Column names for the second list.
                                          This describes the structure of each tuple in list2.
            merge_columns (list): Columns to merge on.
            no_change_query (str): Query string to identify unchanged records.
            changed_query (str): Query string to identify changed records.

        Returns:
            dict: A dictionary containing:
                    success (bool): Whether the operation was successful or not.
                    error_message (str|None): Error message if operation failed, else None.
                    no_change_records (list): List of records with no changes.
                    changed_records (list): List of records with changes.
                    existing_only_records (list): List of records only in existing_inventory.
                    new_only_records (list): List of records only in new_inventory.
        """

        return_dict: dict[str, Any] = {
            "success": False,
            "error_message": None
        }

        merge_suffixes = ('_existing', '_new')

        try:

            existing_df = pd.DataFrame(existing_inventory, columns=existing_inventory_columns)
            new_df = pd.DataFrame(new_inventory, columns=new_inventory_columns)

            merged_df = pd.merge(
                existing_df,
                new_df,
                on=merge_columns,
                how='outer',
                indicator=True,
                suffixes=merge_suffixes
            )

            common_df = merged_df.query("_merge == 'both'", inplace=False)
            existing_only_df = merged_df.query("_merge == 'left_only'", inplace=False)
            new_only_df = merged_df.query("_merge == 'right_only'", inplace=False)

            no_change_df = common_df.query(no_change_query, inplace=False)
            changed_df = common_df.query(changed_query, inplace=False)

        except Exception as e:
            return_dict['error_message'] = f"An error occurred while finding delta: {str(e)}"
            return return_dict

        else:
            return_dict['success'] = True
            return_dict['no_change_records'] = no_change_df.to_dict('records')
            return_dict['changed_records'] = changed_df.to_dict('records')
            return_dict['existing_only_records'] = existing_only_df.to_dict('records')
            return_dict['new_only_records'] = new_only_df.to_dict('records')

        return return_dict
